\# Herramienta de Análisis de Red



Herramienta portable desarrollada en Python para realizar escaneos de red, detección de puertos, identificación básica de vulnerabilidades y exportación de resultados en \*\*JSON, CSV y PDF\*\*.



\## Requisitos

\- instalar `Nmap` y `Npcap` (marcandolo en las opciones de la instalacion).


El instalador incluido en este paquete es:

\- `nmap-7.98-setup`



\## Cómo usar

1.Ejecutar `Ors4NetScan.exe`.

2\. Seleccionar el tipo de escaneo o la funcion que desees.

3\. Exportar los resultados en el formato que desees.



\## Notas

\- La herramienta es completamente portable.

\- Puedes ejecutarla en cualquier PC com Windows 11 o 10, siempre y cuando tengan instalado Nmap y Npcap





