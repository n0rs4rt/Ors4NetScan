# Herramienta de Análisis de Red

Herramienta portable desarrollada en **Python** para realizar escaneos de red, detección de puertos, identificación básica de vulnerabilidades y exportación de resultados en **JSON, CSV y PDF**.

---

## Requisitos

Antes de ejecutar la herramienta, es necesario:

- Instalar **Nmap**
- Instalar **Npcap**, asegurándose de marcar las opciones durante el proceso de instalación

El instalador incluido en este paquete es:

- `nmap-7.98-setup`

---

## Recomendación de Terminal

Para evitar errores de visualización y fallos menores durante la ejecución, se recomienda **no utilizar Terminales obsoletas como el CMD clásico de Windows**.

Se sugiere utilizar **Windows Terminal** como terminal predeterminada.  
Esto puede configurarse fácilmente desde el menú de **Configuración de Windows 11**.

El uso de Windows Terminal mejora la compatibilidad con:

- Colores
- Iconos
- Salida avanzada de la consola

---

